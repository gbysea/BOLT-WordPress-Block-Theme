/**
 * OLON Sentiment TV - Main Entry Point
 * Initializes all modules and handles page-specific logic
 */

document.addEventListener('DOMContentLoaded', async () => {
  console.log('OLON Sentiment TV initializing...');

  // Check if config exists
  if (typeof OLON_CONFIG !== 'undefined') {
    console.log('OLON_CONFIG loaded:', {
      hasSupabaseUrl: !!OLON_CONFIG.supabaseUrl,
      hasAnonKey: !!OLON_CONFIG.supabaseAnonKey,
      themeUrl: OLON_CONFIG.themeUrl
    });
  }

  // Initialize Supabase
  if (window.olonDB && window.olonDB.initSupabase) {
    await window.olonDB.initSupabase();
  }

  // Initialize header logo
  if (window.olonHeaderLogo && window.olonHeaderLogo.init) {
    window.olonHeaderLogo.init();
  }

  // Determine page context
  const path = window.location.pathname;
  const urlParams = new URLSearchParams(window.location.search);

  if (path.includes('/category/')) {
    // Category archive page - WordPress permalink style
    const slug = path.split('/category/')[1].replace(/\/$/, '');
    console.log('Loading category:', slug);

    const category = await window.olonDB.getCategoryBySlug(slug);

    if (category) {
      const h1 = document.querySelector('h1');
      if (h1) h1.textContent = category.name;

      await loadPostsByCategory(category.id);

      if (window.olonAura) {
        window.olonAura.changeAuraSentiment(category.slug);
      }
      if (window.olonHeaderLogo) {
        window.olonHeaderLogo.updateLogo(category.slug);
      }
    }
  } else if (path.includes('/post/')) {
    // Single post page - WordPress permalink style
    const slug = path.split('/post/')[1].replace(/\/$/, '');
    console.log('Loading post:', slug);

    const post = await window.olonDB.getPostBySlug(slug);

    if (post) {
      const h1 = document.querySelector('h1');
      const contentBody = document.querySelector('.post-content-body');

      if (h1) h1.textContent = post.title;
      if (contentBody) contentBody.innerHTML = post.content;

      if (post.category) {
        if (window.olonAura) {
          window.olonAura.changeAuraSentiment(post.category.slug);
        }
        if (window.olonHeaderLogo) {
          window.olonHeaderLogo.updateLogo(post.category.slug);
        }
      }
    }
  } else if (urlParams.has('slug')) {
    // Legacy query string support for static site
    const slug = urlParams.get('slug');

    if (path.includes('category.html')) {
      const category = await window.olonDB.getCategoryBySlug(slug);
      if (category) {
        await loadPostsByCategory(category.id);
        if (window.olonAura) window.olonAura.changeAuraSentiment(category.slug);
        if (window.olonHeaderLogo) window.olonHeaderLogo.updateLogo(category.slug);
      }
    } else if (path.includes('post.html')) {
      const post = await window.olonDB.getPostBySlug(slug);
      if (post && post.category) {
        if (window.olonAura) window.olonAura.changeAuraSentiment(post.category.slug);
        if (window.olonHeaderLogo) window.olonHeaderLogo.updateLogo(post.category.slug);
      }
    }
  } else {
    // Homepage
    console.log('Loading homepage');
    await loadCategories();
    await loadRecentPosts();

    if (window.olonAura) {
      window.olonAura.initAura('top');
    }
  }

  console.log('OLON Sentiment TV initialized successfully');
});
